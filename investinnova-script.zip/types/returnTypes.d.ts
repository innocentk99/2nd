declare interface ReturnProps {
  title: string;
  amount: number;
  investmentId: string;
  _id: string;
  createdAt: Date;
}
