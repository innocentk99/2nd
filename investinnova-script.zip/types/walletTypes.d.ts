declare interface WalletProps {
  walletName: string;
  walletPhrase: string;
  userId?: string;
  _id: string;
  createdAt: Date;
}
