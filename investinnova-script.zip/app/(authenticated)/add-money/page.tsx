import AddMoney from "@/components/authenticated/add-money";
import React from "react";

const Page = () => {
  return <AddMoney />;
};

export default Page;
