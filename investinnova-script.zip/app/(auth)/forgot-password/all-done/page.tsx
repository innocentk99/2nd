import AllDone from "@/components/auth/AllDone";
import React from "react";

const alldone = () => {
  return <AllDone />;
};

export default alldone;
