import Otp from "@/components/auth/Otp";
import React from "react";

const otp = () => {
  return <Otp />;
};

export default otp;
